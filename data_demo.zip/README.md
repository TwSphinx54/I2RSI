# Data demo

Here are data for test. Dictionary structure is as follows:

* **CD**: Change Detection

* **OC**: Object Classification

* **OD**: Object Detection

* **OE**: Object Extraction

  