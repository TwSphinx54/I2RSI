PaddleSeg commit fec42fd869b6f796c74cd510671595e3512bc8e9

# 开发规范
请注意，paddlers/models/ppxxx系列除了修改import路径和支持多通道模型外，不要增删改任何代码。
新增的模型需放在paddlers/models/下的seg、det、cls、cd目录下。