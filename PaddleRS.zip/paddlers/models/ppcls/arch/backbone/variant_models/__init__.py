from .resnet_variant import ResNet50_last_stage_stride1
from .vgg_variant import VGG19Sigmoid
from .pp_lcnet_variant import PPLCNet_x2_5_Tanh
